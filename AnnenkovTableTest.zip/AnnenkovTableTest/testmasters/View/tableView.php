<?php
class TableView {
    public static function getTable($data,$title = []) {
        $tableHTML = "<div class='table'>";

        foreach($title as $value) {
            $tableHTML .= "<div class='cell title'>"."<div class='text-block'>".$value."</div>"."</div>";
        }

        foreach($data as $object) {
            foreach($object as $value) {
                $tableHTML .= "<div class='cell'>"."<div class='text-block'>".$value."</div>"."</div>";
            }
            $tableHTML .= "<div class='cell'>"."<div data-id='".$object['id']."' class='button'>Дополнительная информация</div>"."</div>";
        }

        $tableHTML .= "</div>";

        echo $tableHTML;
    }
}
?>