<?php
class ModalView {
    public static function getModal() {
        $modalHTML = "<div class='overlay'>";
        $modalHTML .= "<div class='modal'>";
        $modalHTML .= "<div class='content'></div>";
        $modalHTML .= "<div class= 'close-button'>Закрыть</div>";
        $modalHTML .= "</div></div>";
        echo $modalHTML;
    }
}
?>