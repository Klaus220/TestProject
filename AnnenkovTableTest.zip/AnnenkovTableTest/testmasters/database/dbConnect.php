<?php
class dbConnect {
    private static $instanse;
    private $connection;

    private function __construct() 
    {
        $this->connection = new PDO("mysql:host=localhost;dbname=test_masters_bd", "root", "");
    }

    public static function getConnection() 
    {
        if (self::$instanse === null) {
            self::$instanse = new self();
        }
        return self::$instanse;
    }

    public function query(string $sql, array $params = [], string $className = 'stdClass'): ?array
    {
        $statement = $this->connection->prepare($sql);
        $result = $statement->execute($params);

        if (false === $result) {
            return null;
        }

        return $statement->fetchAll(\PDO::FETCH_CLASS, $className);

    }
}
?>