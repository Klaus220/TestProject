<?php
include_once './database/dbConnect.php';
class Students {
    public static function getAll() {
        $db = dbConnect::getConnection();
        $sql = "SELECT * FROM students";
        return $db->query($sql);
    }

    public static function getTableData($fetch) {
        $students = json_decode(json_encode($fetch),true);
        $data = [];
        foreach($students as $oneStudent) {
            $object['id'] = $oneStudent['id'];
            $object['name'] = $oneStudent['name'].' '.$oneStudent['second_name'];
            $object['study_dir'] = $oneStudent['study_dir'];
            $data[] = $object;
        }
        return $data;
    }
}
?>