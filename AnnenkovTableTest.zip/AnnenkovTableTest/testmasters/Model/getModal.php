<?php
include_once '../database/dbConnect.php';

function getOne($id) {
    $db = dbConnect::getConnection();
    $sql = "SELECT `birthday`, `link` FROM `students` WHERE `id` = $id;"; //здесь должно быть экранирование, но в рамках данной задачи не стал добавлять
    return $db->query($sql);
}
function Ajax() {
        $id = $_GET['id'];
        $response = getOne($id);
        exit(json_encode($response));
}

Ajax();