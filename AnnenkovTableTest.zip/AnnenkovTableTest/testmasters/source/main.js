document.addEventListener("DOMContentLoaded", docLoad);

function docLoad() {
    let buttons = document.querySelectorAll('[data-id]');
    buttons.forEach(element => {
        addButtonClickEvent(element);
    });
    addModalEvent();
}

function addButtonClickEvent(buttons) {
    buttons.addEventListener("click", getModalWindow);
}

function getModalWindow(Event) {
    let requestURL = `http://testmasters/Model/getModal.php?id=${Event.target.getAttribute('data-id')}`;
    sendRequest(requestURL);
}

function sendRequest(requestURL) {
    let xmlHR = new XMLHttpRequest();
    xmlHR.open('GET',requestURL,false);
    xmlHR.onreadystatechange = function() {
        if (xmlHR.readyState !== 4 || xmlHR.status !== 200) return;
        let response = xmlHR.response;
        createModalWindow(response);
    }
    xmlHR.send();
}

function createModalWindow(response) {
    let modal = document.querySelector('.modal .content');
    let data = JSON.parse(response)[0];
    modal.innerHTML = `Дата рождения: ${data['birthday']}<br>Личное дело: <a href='#'>${data['link']}</a>`;
    document.querySelector('.overlay').style.display = 'flex';
}

function addModalEvent() {
    document.querySelector('.modal .close-button').addEventListener('click',function(){
        document.querySelector('.overlay').style.display = 'none';
    })
}
